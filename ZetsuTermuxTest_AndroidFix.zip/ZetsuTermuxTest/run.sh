#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
set +x
umask 077
cd -- "$(dirname -- "$0")"
case "$(uname -m)" in
  aarch64|arm64) agent=./agent-arm64 ;;
  *) printf 'Versi tes ini khusus Android arm64; arsitektur belum didukung.\n'; exit 1 ;;
esac
chmod 700 "$agent"
printf 'Zetsu Termux Test 0.1.1 — Android arm64 PIE\n'
case "${1:-}" in
  check) exec "$agent" check ;;
  test)
    printf 'Matikan Auto Rejoin dan Rotasi pada Zetsu selama tes ini.\n'
    "$agent" check
    secret=''
    trap 'unset secret' EXIT
    IFS= read -r -s -p 'Tempel cookie akun sendiri (input tersembunyi), lalu Enter: ' secret </dev/tty
    printf '\n' >/dev/tty
    # printf is a bash builtin: the cookie never becomes a process argument.
    printf '%s\n' "$secret" | "$agent" test
    unset secret
    ;;
  *) printf 'Gunakan: bash run.sh check\nLalu: bash run.sh test\n'; exit 2 ;;
esac
