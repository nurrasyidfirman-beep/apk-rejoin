package com.zetsu.multilauncher.rejoin;

/** Standalone helper dependency; matching storage is not proof of login. */
public final class CookieSessionPolicy {
    public static boolean safeStorage(String value) {
        return value!=null && value.matches("NATIVE=(MATCH|MISSING|DIFFERENT|UNKNOWN) WEBVIEW=(MATCH|MISSING|DIFFERENT|ENCRYPTED|UNKNOWN) CACHE=(MATCH|MISSING|DIFFERENT|UNKNOWN) OVERRIDE=(NONE|MATCH|OTHER|UNKNOWN)");
    }
}
