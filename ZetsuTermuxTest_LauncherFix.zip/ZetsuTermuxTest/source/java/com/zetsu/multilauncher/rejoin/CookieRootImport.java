package com.zetsu.multilauncher.rejoin;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.system.Os;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

/** Android-only entry point, run by su/app_process. No cookie is ever printed. */
public final class CookieRootImport {
    private static final class Abort extends Exception { final String code; Abort(String code) { super(code); this.code=code; } }
    public static void main(String[] args) {
        String result="IMPORT_FAILED";
        try { result=importCookie(args); }
        catch(Abort error) { result=error.code; }
        catch(Throwable ignored) { /* Never print exception messages, SQL parameters or stack traces. */ }
        System.out.print(result); System.out.flush(); System.exit("OK".equals(result) || CookieSessionPolicy.safeStorage(result)?0:1);
    }
    static String importCookie(String[] args) throws Exception {
        if(Os.getuid()!=0) throw new Abort("ROOT");
        if(args.length!=4 || !("import".equals(args[3]) || "inspect".equals(args[3]))) throw new Abort("PATH");
        String pkg=args[0]; int uid=Integer.parseInt(args[2]); File root=new File(args[1]).getCanonicalFile();
        if(!CookiePolicy.dataPath(pkg,root.getPath(),uid) || Os.stat(root.getPath()).st_uid!=uid) throw new Abort("PATH");
        DataInputStream input=new DataInputStream(System.in); int length=input.readInt();
        if(length<64 || length>8192) throw new Abort("IMPORT_FAILED");
        byte[] bytes=new byte[length]; input.readFully(bytes);
        String cookie;
        try { cookie=CookiePolicy.normalize(new String(bytes,StandardCharsets.UTF_8)); } finally { Arrays.fill(bytes,(byte)0); }
        long accountId=input.readLong(); String username=input.readUTF(),displayName=input.readUTF();
        if(accountId<=0 || !username.matches("[A-Za-z0-9_]{1,50}") || displayName.length()>100) throw new Abort("IMPORT_FAILED");
        List<File> profiles=new ArrayList<>();
        for(String path:new String[]{"app_webview/Cookies","app_webview/Default/Cookies"}) {
            File file=inside(root,path); if(file.isFile()) profiles.add(file);
        }
        if(profiles.isEmpty() && !"inspect".equals(args[3])) throw new Abort("WEBVIEW_MISSING");
        if(profiles.size()>1) throw new Abort("WEBVIEW_MULTIPLE");
        File database=profiles.isEmpty()?null:profiles.get(0),prefs=inside(root,"shared_prefs"),nativeFile=inside(root,"shared_prefs/WebViewCookieHandlerNativeStorage.xml");
        File accountFile=accountFile(root);
        String override=override(cookie);
        if("inspect".equals(args[3])) return inspect(root,database,nativeFile,accountFile,cookie,accountId,username,uid,override);
        if("OTHER".equals(override) || "UNKNOWN".equals(override)) throw new Abort("GLOBAL_OVERRIDE");
        if(Os.stat(database.getPath()).st_uid!=uid) throw new Abort("OWNERSHIP");
        if(nativeFile.exists() && Os.stat(nativeFile.getPath()).st_uid!=uid) throw new Abort("OWNERSHIP");
        if(accountFile.exists() && Os.stat(accountFile.getPath()).st_uid!=uid) throw new Abort("OWNERSHIP");
        // Stop only the validated package and current (primary) Android user. No wildcard or data clear.
        if(run("/system/bin/am","force-stop","--user","0",pkg)!=0) throw new Abort("STOP_FAILED");
        if(inside(root,"shared_prefs/WebViewCookieHandlerNativeStorage.xml.bak").exists() || inside(root,"shared_prefs/"+accountFile.getName()+".bak").exists()) throw new Abort("NATIVE_FORMAT");
        byte[] old=nativeFile.exists()?read(nativeFile):null;
        byte[] replacement=nativeXml(old,cookie);
        byte[] oldAccount=accountFile.exists()?read(accountFile):null;
        byte[] newAccount=accountXml(oldAccount,accountId,username,displayName);
        boolean madeDir=false;
        if(!prefs.exists()) { if(!prefs.mkdir()) throw new Abort("OWNERSHIP"); madeDir=true; }
        if(madeDir) { Os.chown(prefs.getPath(),uid,uid); Os.chmod(prefs.getPath(),0700); context(prefs); }
        else if(Os.stat(prefs.getPath()).st_uid!=uid) throw new Abort("OWNERSHIP");
        File staged=inside(root,"shared_prefs/.zetsu-cookie-"+UUID.randomUUID()+".xml");
        File stagedAccount=inside(root,"shared_prefs/.zetsu-profile-"+UUID.randomUUID()+".xml");
        SQLiteDatabase db=null; boolean transaction=false,nativeChanged=false,accountChanged=false,committed=false,commitAttempted=false;
        try {
            db=SQLiteDatabase.openDatabase(database.getPath(),null,SQLiteDatabase.OPEN_READWRITE|SQLiteDatabase.NO_LOCALIZED_COLLATORS);
            Map<String,Boolean> columns=new LinkedHashMap<>();
            Set<String> supported=new HashSet<>(Arrays.asList("creation_utc","host_key","top_frame_site_key","name","value","encrypted_value","path","expires_utc","is_secure","is_httponly","last_access_utc","has_expires","is_persistent","priority","samesite","source_scheme","source_port","is_same_party","last_update_utc","source_type","has_cross_site_ancestor"));
            try(Cursor c=db.rawQuery("PRAGMA table_info(cookies)",null)) {
                while(c.moveToNext()) {
                    String name=c.getString(1); columns.put(name,true);
                    if(!supported.contains(name) && c.getInt(3)!=0 && c.isNull(4) && c.getInt(5)==0) throw new Abort("SCHEMA");
                }
            }
            if(!columns.keySet().containsAll(Arrays.asList("host_key","name","value","path","creation_utc","expires_utc","is_secure","is_httponly","last_access_utc","has_expires","is_persistent"))) throw new Abort("SCHEMA");
            if(columns.containsKey("encrypted_value")) {
                try(Cursor c=db.rawQuery("SELECT host_key,length(encrypted_value) FROM cookies",null)) {
                    while(c.moveToNext()) if(CookiePolicy.robloxHost(c.getString(0)) && c.getInt(1)>0) throw new Abort("ENCRYPTED");
                }
            }
            // Prepare and label the native store before either backend is changed.
            write(staged,replacement,uid); context(staged);
            write(stagedAccount,newAccount,uid); context(stagedAccount);
            db.beginTransaction(); transaction=true;
            db.delete("cookies","name=? AND (host_key=? OR host_key LIKE ?)",new String[]{".ROBLOSECURITY","roblox.com","%.roblox.com"});
            ContentValues values=new ContentValues();
            long now=(System.currentTimeMillis()+11644473600000L)*1000L;
            put(values,columns,"host_key",".roblox.com"); put(values,columns,"name",".ROBLOSECURITY"); put(values,columns,"value",cookie); put(values,columns,"path","/");
            put(values,columns,"top_frame_site_key","");
            for(String field:new String[]{"creation_utc","last_access_utc","last_update_utc"}) put(values,columns,field,now);
            put(values,columns,"expires_utc",now+30L*86400*1000000);
            for(String field:new String[]{"is_secure","is_httponly","has_expires","is_persistent","priority"}) put(values,columns,field,1);
            put(values,columns,"samesite",-1); put(values,columns,"source_scheme",2); put(values,columns,"source_port",443);
            for(String field:new String[]{"is_same_party","source_type","has_cross_site_ancestor"}) put(values,columns,field,0);
            if(columns.containsKey("encrypted_value")) values.put("encrypted_value",new byte[0]);
            if(db.insertOrThrow("cookies",null,values)<0) throw new Abort("IMPORT_FAILED");
            // Confirm the parameterized write inside the same transaction; never print its value.
            try(Cursor c=db.query("cookies",new String[]{"value"},"host_key=? AND name=? AND path=?",new String[]{".roblox.com",".ROBLOSECURITY","/"},null,null,null)) {
                if(!c.moveToFirst() || !cookie.equals(c.getString(0)) || c.moveToNext()) throw new Abort("IMPORT_FAILED");
            }
            Os.rename(staged.getPath(),nativeFile.getPath()); nativeChanged=true;
            Os.rename(stagedAccount.getPath(),accountFile.getPath()); accountChanged=true;
            db.setTransactionSuccessful(); commitAttempted=true; db.endTransaction(); transaction=false; committed=true;
        } catch(Exception failure) {
            if(transaction) { try { db.endTransaction(); } catch(Exception ignored) {} transaction=false; }
            if(commitAttempted) throw new Abort("PARTIAL");
            if((nativeChanged || accountChanged) && !committed) {
                try {
                    if(nativeChanged) restore(staged,nativeFile,old,uid);
                    if(accountChanged) restore(stagedAccount,accountFile,oldAccount,uid);
                } catch(Exception rollback) { throw new Abort("PARTIAL"); }
            }
            if(failure instanceof Abort) throw failure;
            throw new Abort("IMPORT_FAILED");
        } finally {
            if(db!=null) db.close();
            if(staged.exists()) staged.delete();
            if(stagedAccount.exists()) stagedAccount.delete();
            Arrays.fill(replacement,(byte)0); if(old!=null) Arrays.fill(old,(byte)0);
            Arrays.fill(newAccount,(byte)0); if(oldAccount!=null) Arrays.fill(oldAccount,(byte)0);
            // SQLite can create journals as root. Restore target ownership on those exact files.
            for(String suffix:new String[]{"","-wal","-shm","-journal"}) {
                File file=inside(root,root.toPath().relativize(database.toPath()).toString()+suffix);
                if(file.exists()) { try { Os.chown(file.getPath(),uid,uid); Os.chmod(file.getPath(),0600); context(file); } catch(Exception error) { if(committed) throw new Abort("PARTIAL"); else throw new Abort("OWNERSHIP"); } }
            }
        }
        return "OK";
    }
    private static File accountFile(File root) throws Exception {
        // Exact inspected APK: rg/w0.U -> ek/y.b -> mh/b.a() == false.
        // Channel prefixing is therefore disabled; unrelated *_prefs.xml files are not candidates.
        File file=inside(root,"shared_prefs/prefs.xml");
        if(file.exists() && !file.isFile()) throw new Abort("NATIVE_FORMAT");
        return file;
    }
    private static void restore(File staged,File target,byte[] previous,int uid) throws Exception {
        if(previous==null) { if(!target.delete()) throw new IOException(); }
        else { write(staged,previous,uid); context(staged); Os.rename(staged.getPath(),target.getPath()); }
    }
    private static String override(String cookie) {
        File file=new File("/data/local/tmp/ClientAppSettings.json");
        if(!file.exists()) return "NONE";
        try {
            org.json.JSONObject json=new org.json.JSONObject(new String(read(file),StandardCharsets.UTF_8));
            if(!json.has("FStringAuthCookie")) return "NONE";
            return cookie.equals(json.getString("FStringAuthCookie"))?"MATCH":"OTHER";
        } catch(Exception ignored) { return "UNKNOWN"; }
    }
    private static String inspect(File root,File database,File nativeFile,File accountFile,String cookie,long id,String username,int uid,String override) throws Exception {
        String nativeState="MISSING",cache="MISSING",web="MISSING";
        try { if(nativeFile.exists()) { String actual=field(read(nativeFile),".ROBLOSECURITY"); nativeState=actual==null || actual.isEmpty()?"MISSING":cookie.equals(actual)?"MATCH":"DIFFERENT"; } } catch(Exception ignored) { nativeState="UNKNOWN"; }
        try { if(accountFile.exists()) { byte[] xml=read(accountFile); String user=field(xml,"userid_long"),name=field(xml,"username"); cache=user==null?"MISSING":String.valueOf(id).equals(user) && username.equals(name)?"MATCH":"DIFFERENT"; Arrays.fill(xml,(byte)0); } } catch(Exception ignored) { cache="UNKNOWN"; }
        SQLiteDatabase db=null;
        try {
            if(database==null) return "NATIVE="+nativeState+" WEBVIEW=MISSING CACHE="+cache+" OVERRIDE="+override;
            db=SQLiteDatabase.openDatabase(database.getPath(),null,SQLiteDatabase.OPEN_READONLY|SQLiteDatabase.NO_LOCALIZED_COLLATORS);
            boolean encrypted=false; try(Cursor c=db.rawQuery("PRAGMA table_info(cookies)",null)) { while(c.moveToNext()) if("encrypted_value".equals(c.getString(1))) encrypted=true; }
            boolean match=false,different=false,enc=false;
            try(Cursor c=db.query("cookies",encrypted?new String[]{"host_key","value","encrypted_value"}:new String[]{"host_key","value"},"name=?",new String[]{".ROBLOSECURITY"},null,null,null)) {
                while(c.moveToNext()) if(CookiePolicy.robloxHost(c.getString(0))) {
                    if(encrypted && !c.isNull(2) && c.getBlob(2).length>0) enc=true;
                    else if(cookie.equals(c.getString(1))) match=true;
                    else if(!c.isNull(1) && !c.getString(1).isEmpty()) different=true;
                }
            }
            web=enc?"ENCRYPTED":different?"DIFFERENT":match?"MATCH":"MISSING";
        } catch(Exception ignored) { web="UNKNOWN"; }
        finally {
            if(db!=null) try { db.close(); } catch(Exception ignored) {}
            for(String suffix:database==null?new String[0]:new String[]{"-wal","-shm","-journal"}) {
                File file=inside(root,root.toPath().relativize(database.toPath()).toString()+suffix);
                if(file.exists() && Os.stat(file.getPath()).st_uid==0) { Os.chown(file.getPath(),uid,uid); Os.chmod(file.getPath(),0600); context(file); }
            }
        }
        return "NATIVE="+nativeState+" WEBVIEW="+web+" CACHE="+cache+" OVERRIDE="+override;
    }
    private static Document document(byte[] old) throws Exception {
        DocumentBuilderFactory factory=DocumentBuilderFactory.newInstance(); factory.setExpandEntityReferences(false);
        if(old!=null) for(byte b:old) if(b==0) throw new Abort("NATIVE_FORMAT");
        if(old!=null && new String(old,StandardCharsets.UTF_8).contains("<!")) throw new Abort("NATIVE_FORMAT");
        javax.xml.parsers.DocumentBuilder builder=factory.newDocumentBuilder();
        builder.setErrorHandler(new org.xml.sax.helpers.DefaultHandler() {
            public void error(org.xml.sax.SAXParseException e) throws org.xml.sax.SAXException { throw e; }
            public void fatalError(org.xml.sax.SAXParseException e) throws org.xml.sax.SAXException { throw e; }
        });
        Document doc=old==null?builder.newDocument():builder.parse(new ByteArrayInputStream(old));
        if(old==null) doc.appendChild(doc.createElement("map"));
        if(!"map".equals(doc.getDocumentElement().getTagName())) throw new Abort("NATIVE_FORMAT");
        return doc;
    }
    private static String field(byte[] old,String key) throws Exception {
        NodeList nodes=document(old).getDocumentElement().getChildNodes();
        String value=null;
        for(int i=0;i<nodes.getLength();i++) if(nodes.item(i) instanceof Element) {
            Element item=(Element)nodes.item(i); if(key.equals(item.getAttribute("name"))) value=item.hasAttribute("value")?item.getAttribute("value"):item.getTextContent();
        }
        return value;
    }
    private static byte[] accountXml(byte[] old,long id,String username,String displayName) throws Exception {
        try {
            Document doc=document(old); Element map=doc.getDocumentElement(); NodeList nodes=map.getChildNodes();
            String previous=old==null?null:field(old,"userid_long");
            Set<String> replace=new HashSet<>(Arrays.asList("userid","userid_long","username","displayName","last_auth_cookie_expir_key","user_logged_in_time"));
            // Don't carry another account's age setting. Its actual setting will be fetched by Roblox.
            if(!String.valueOf(id).equals(previous)) replace.add("under13");
            for(int i=nodes.getLength()-1;i>=0;i--) if(nodes.item(i) instanceof Element && replace.contains(((Element)nodes.item(i)).getAttribute("name"))) map.removeChild(nodes.item(i));
            Element user=doc.createElement("long"); user.setAttribute("name","userid_long"); user.setAttribute("value",String.valueOf(id)); map.appendChild(user);
            for(String[] entry:new String[][]{{"username",username},{"displayName",displayName}}) { Element item=doc.createElement("string"); item.setAttribute("name",entry[0]); item.setTextContent(entry[1]); map.appendChild(item); }
            ByteArrayOutputStream out=new ByteArrayOutputStream(); Transformer transformer=TransformerFactory.newInstance().newTransformer(); transformer.setOutputProperty(OutputKeys.ENCODING,"UTF-8"); transformer.transform(new DOMSource(doc),new StreamResult(out)); return out.toByteArray();
        } catch(Exception ignored) { throw new Abort("NATIVE_FORMAT"); }
    }
    private static File inside(File root,String path) throws Exception {
        File file=new File(root,path),canonical=file.getCanonicalFile();
        if(!canonical.getPath().startsWith(root.getPath()+File.separator) || !file.getAbsolutePath().equals(canonical.getPath())) throw new Abort("PATH");
        return canonical;
    }
    private static byte[] read(File file) throws Exception {
        if(file.length()>1048576) throw new Abort("NATIVE_FORMAT");
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        try(InputStream in=new FileInputStream(file)) { byte[] b=new byte[4096]; int n; while((n=in.read(b))!=-1) { if(out.size()+n>1048576) throw new Abort("NATIVE_FORMAT"); out.write(b,0,n); } } return out.toByteArray();
    }
    private static byte[] nativeXml(byte[] old,String cookie) throws Exception {
        try {
            DocumentBuilderFactory factory=DocumentBuilderFactory.newInstance(); factory.setExpandEntityReferences(false);
            if(old!=null) for(byte b:old) if(b==0) throw new Abort("NATIVE_FORMAT");
            // Reject external entity/DOCTYPE input without relying on vendor-specific XML parser features.
            if(old!=null && new String(old,StandardCharsets.UTF_8).contains("<!")) throw new Abort("NATIVE_FORMAT");
            javax.xml.parsers.DocumentBuilder builder=factory.newDocumentBuilder();
            builder.setErrorHandler(new org.xml.sax.helpers.DefaultHandler() {
                public void error(org.xml.sax.SAXParseException e) throws org.xml.sax.SAXException { throw e; }
                public void fatalError(org.xml.sax.SAXParseException e) throws org.xml.sax.SAXException { throw e; }
            });
            Document doc=old==null?builder.newDocument():builder.parse(new ByteArrayInputStream(old));
            Element map;
            if(old==null) { map=doc.createElement("map"); doc.appendChild(map); }
            else { map=doc.getDocumentElement(); if(!"map".equals(map.getTagName())) throw new Abort("NATIVE_FORMAT"); }
            NodeList nodes=map.getChildNodes();
            for(int i=nodes.getLength()-1;i>=0;i--) if(nodes.item(i) instanceof Element) {
                Element item=(Element)nodes.item(i); String key=item.getAttribute("name");
                if(".ROBLOSECURITY".equals(key) || "__migrated_from_webview_v3__".equals(key)) map.removeChild(item);
            }
            Element secret=doc.createElement("string"); secret.setAttribute("name",".ROBLOSECURITY"); secret.setTextContent(cookie); map.appendChild(secret);
            Element marker=doc.createElement("boolean"); marker.setAttribute("name","__migrated_from_webview_v3__"); marker.setAttribute("value","true"); map.appendChild(marker);
            ByteArrayOutputStream out=new ByteArrayOutputStream(); Transformer transformer=TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.ENCODING,"UTF-8"); transformer.transform(new DOMSource(doc),new StreamResult(out)); return out.toByteArray();
        } catch(Abort error) { throw error; } catch(Exception error) { throw new Abort("NATIVE_FORMAT"); }
    }
    private static void write(File file,byte[] bytes,int uid) throws Exception {
        try(FileOutputStream out=new FileOutputStream(file)) { Os.chmod(file.getPath(),0600); out.write(bytes); out.getFD().sync(); }
        Os.chown(file.getPath(),uid,uid);
    }
    private static void context(File file) throws Exception { if(run("/system/bin/restorecon","-F",file.getPath())!=0) throw new Abort("OWNERSHIP"); }
    private static int run(String... command) throws Exception {
        Process process=new ProcessBuilder(command).redirectErrorStream(true).start();
        try(InputStream in=process.getInputStream()) { byte[] discard=new byte[2048]; while(in.read(discard)!=-1) {} }
        return process.waitFor();
    }
    private static void put(ContentValues values,Map<String,Boolean> cols,String name,String value) { if(cols.containsKey(name)) values.put(name,value); }
    private static void put(ContentValues values,Map<String,Boolean> cols,String name,long value) { if(cols.containsKey(name)) values.put(name,value); }
}
