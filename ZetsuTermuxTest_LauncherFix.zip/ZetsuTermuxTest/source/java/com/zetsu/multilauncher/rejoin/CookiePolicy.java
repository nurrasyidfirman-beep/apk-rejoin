package com.zetsu.multilauncher.rejoin;

/** Strict local input and package/path validation, also used by the root helper. */
public final class CookiePolicy {
    public static final String PACKAGE="com.roblox.clienu";
    public static final String APK_HASH="7a1dbe342ef214f1b14269e9240186a76221c61a44f7ac5418c4f269574c20ce";
    public static String normalize(String input) {
        if(input==null || input.length()>16384 || input.indexOf('\n')>=0 || input.indexOf('\r')>=0) throw new IllegalArgumentException("COOKIE_FORMAT");
        String value=input.trim();
        if(value.startsWith(".ROBLOSECURITY=")) { value=value.substring(15); int end=value.indexOf(';'); if(end>=0) value=value.substring(0,end); }
        if(value.length()<64 || value.length()>8192) throw new IllegalArgumentException("COOKIE_FORMAT");
        for(int i=0;i<value.length();i++) { char ch=value.charAt(i); if(ch<33 || ch>126 || ch==';' || ch=='"' || ch==',') throw new IllegalArgumentException("COOKIE_FORMAT"); }
        return value;
    }
    public static boolean supported(String pkg,long version,int sdk,int uid) {
        return PACKAGE.equals(pkg) && version==3170 && sdk==29 && uid>=10000 && uid<100000;
    }
    public static boolean dataPath(String pkg,String canonical,int uid) {
        return PACKAGE.equals(pkg) && uid>=10000 && uid<100000 && (("/data/user/0/"+pkg).equals(canonical) || ("/data/data/"+pkg).equals(canonical));
    }
    public static boolean robloxHost(String host) { return host!=null && ("roblox.com".equals(host) || host.endsWith(".roblox.com")); }
}
