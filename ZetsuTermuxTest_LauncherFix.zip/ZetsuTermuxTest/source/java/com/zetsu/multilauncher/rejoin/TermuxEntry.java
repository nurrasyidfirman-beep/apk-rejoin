package com.zetsu.multilauncher.rejoin;

import android.system.Os;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import java.util.regex.*;
import javax.net.ssl.HttpsURLConnection;
import org.json.JSONObject;

/** Root entry point, no UI APK and no credentials in argv, logs or error messages. */
public final class TermuxEntry {
    private static final class Fail extends Exception {
        final String code; Fail(String code) { this.code=code; }
    }
    private static final class Target {
        final String path; final int uid;
        Target(String path,int uid) { this.path=path; this.uid=uid; }
    }
    public static void main(String[] args) {
        JSONObject reply=new JSONObject(); int status=1;
        try {
            if(args.length!=1 || !Arrays.asList("check","validate","import","inspect","open").contains(args[0])) throw new Fail("COMMAND");
            Target target=target();
            String mode=args[0];
            if("check".equals(mode)) {
                reply.put("package",CookiePolicy.PACKAGE); reply.put("sdk",29); reply.put("uid",target.uid);
                reply.put("dataDir",target.path); reply.put("apkVerified",true);
            } else if("validate".equals(mode)) {
                DataInputStream input=new DataInputStream(System.in); int length=input.readInt();
                if(length<64 || length>8192) throw new Fail("COOKIE_FORMAT");
                byte[] bytes=new byte[length]; input.readFully(bytes);
                String cookie;
                try { cookie=CookiePolicy.normalize(new String(bytes,StandardCharsets.UTF_8)); }
                finally { Arrays.fill(bytes,(byte)0); }
                account(cookie,reply);
            } else if("open".equals(mode)) {
                String out=run("/system/bin/am","start","--user","0","-W","-n",CookiePolicy.PACKAGE+"/com.roblox.client.startup.ActivitySplash");
                if(!out.contains("Status: ok") || out.contains("Error:")) throw new Fail("OPEN_FAILED");
            } else {
                try {
                    String snapshot=CookieRootImport.importCookie(new String[]{CookiePolicy.PACKAGE,target.path,String.valueOf(target.uid),mode});
                    if(!"OK".equals(snapshot) && !CookieSessionPolicy.safeStorage(snapshot)) throw new Fail("HELPER_RESULT");
                    if(!"OK".equals(snapshot)) reply.put("snapshot",snapshot);
                } catch(Fail error) { throw error; }
                catch(Exception error) {
                    // Only allowlisted internal codes; never exception text from SQLite/XML/network.
                    String code=error.getMessage();
                    if(code!=null && Arrays.asList("ROOT","PATH","WEBVIEW_MISSING","WEBVIEW_MULTIPLE","GLOBAL_OVERRIDE","OWNERSHIP","STOP_FAILED","NATIVE_FORMAT","SCHEMA","ENCRYPTED","PARTIAL","IMPORT_FAILED").contains(code)) throw new Fail(code);
                    throw new Fail("IMPORT_FAILED");
                }
            }
            reply.put("ok",true); status=0;
        } catch(Fail error) { try { reply.put("ok",false); reply.put("error",error.code); } catch(Exception ignored) {} }
        catch(Throwable error) { try { reply.put("ok",false); reply.put("error","HELPER_FAILED"); } catch(Exception ignored) {} }
        System.out.println(reply.toString()); System.out.flush(); System.exit(status);
    }
    private static Target target() throws Exception {
        if(Os.getuid()!=0) throw new Fail("ROOT");
        if(!"29".equals(run("/system/bin/getprop","ro.build.version.sdk").trim())) throw new Fail("SDK_UNSUPPORTED");
        if(!"0".equals(run("/system/bin/am","get-current-user").trim())) throw new Fail("USER_UNSUPPORTED");
        String dump=run("/system/bin/dumpsys","package",CookiePolicy.PACKAGE);
        int uid=Integer.parseInt(match(dump,"(?m)^\\s*userId=([0-9]+)\\s*$","PACKAGE_MISSING"));
        long version=Long.parseLong(match(dump,"\\bversionCode=([0-9]+)\\b","PACKAGE_MISSING"));
        if(!CookiePolicy.supported(CookiePolicy.PACKAGE,version,29,uid)) throw new Fail("PACKAGE_UNSUPPORTED");
        String path=new File(match(dump,"(?m)^\\s*dataDir=(\\S+)\\s*$","PATH")).getCanonicalPath();
        if(!CookiePolicy.dataPath(CookiePolicy.PACKAGE,path,uid) || Os.stat(path).st_uid!=uid) throw new Fail("PATH");
        String apk=run("/system/bin/pm","path","--user","0",CookiePolicy.PACKAGE).trim();
        if(!apk.startsWith("package:") || apk.indexOf('\n')>=0 || apk.indexOf('\r')>=0) throw new Fail("APK_UNSUPPORTED");
        File source=new File(apk.substring(8));
        if(!source.isFile()) throw new Fail("APK_UNSUPPORTED");
        MessageDigest digest=MessageDigest.getInstance("SHA-256");
        try(InputStream in=new FileInputStream(source)) { byte[] bytes=new byte[32768]; int n; while((n=in.read(bytes))!=-1) digest.update(bytes,0,n); }
        StringBuilder hex=new StringBuilder(); for(byte b:digest.digest()) hex.append(String.format(Locale.ROOT,"%02x",b&255));
        if(!CookiePolicy.APK_HASH.equals(hex.toString())) throw new Fail("APK_UNSUPPORTED");
        return new Target(path,uid);
    }
    private static String match(String value,String expression,String code) throws Exception {
        Matcher matcher=Pattern.compile(expression).matcher(value); if(!matcher.find()) throw new Fail(code); return matcher.group(1);
    }
    private static String run(String... command) throws Exception {
        Process process=new ProcessBuilder(command).redirectError(ProcessBuilder.Redirect.INHERIT).start();
        ByteArrayOutputStream output=new ByteArrayOutputStream();
        try(InputStream in=process.getInputStream()) { byte[] bytes=new byte[4096]; int n; while((n=in.read(bytes))!=-1) { if(output.size()+n>1048576) { process.destroy(); throw new Fail("COMMAND_FAILED"); } output.write(bytes,0,n); } }
        if(process.waitFor()!=0) throw new Fail("COMMAND_FAILED");
        return new String(output.toByteArray(),StandardCharsets.UTF_8);
    }
    private static void account(String cookie,JSONObject reply) throws Exception {
        HttpsURLConnection connection=(HttpsURLConnection)new URL("https://users.roblox.com/v1/users/authenticated").openConnection();
        connection.setConnectTimeout(12000); connection.setReadTimeout(12000); connection.setInstanceFollowRedirects(false);
        connection.setRequestProperty("Cookie",".ROBLOSECURITY="+cookie);
        try {
            int code=connection.getResponseCode();
            if(code==401 || code==403) throw new Fail("COOKIE_REJECTED");
            if(code!=200) throw new Fail("HTTP_"+code);
            ByteArrayOutputStream out=new ByteArrayOutputStream();
            try(InputStream in=connection.getInputStream()) { byte[] bytes=new byte[1024]; int n; while((n=in.read(bytes))!=-1) { if(out.size()+n>8192) throw new Fail("API_FORMAT"); out.write(bytes,0,n); } }
            JSONObject user=new JSONObject(new String(out.toByteArray(),StandardCharsets.UTF_8));
            long id=user.getLong("id"); String name=user.getString("name"),display=user.getString("displayName");
            if(id<=0 || !name.matches("[A-Za-z0-9_]{1,50}") || display.length()>100) throw new Fail("API_FORMAT");
            reply.put("id",id); reply.put("username",name); reply.put("displayName",display);
        } catch(Fail error) { throw error; }
        catch(Exception error) { throw new Fail("NETWORK"); }
        finally { connection.disconnect(); }
    }
}
