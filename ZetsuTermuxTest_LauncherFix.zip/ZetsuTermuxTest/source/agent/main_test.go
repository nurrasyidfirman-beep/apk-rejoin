package main

import (
	"bytes"
	"encoding/binary"
	"strings"
	"testing"
)

func TestCookieInput(t *testing.T) {
	raw := "_|WARNING:" + strings.Repeat("a", 100)
	value, err := normalize(".ROBLOSECURITY=" + raw + "; Path=/; Secure")
	if err != nil || value != raw {
		t.Fatal("cookie prefix damaged")
	}
	for _, bad := range []string{"short", raw + "\n", raw + "\r", raw + ";x", raw + ",x", raw + "\"", strings.Repeat("a", 8193)} {
		if _, err := normalize(bad); err == nil {
			t.Fatal("invalid cookie accepted")
		}
	}
}
func TestJavaModifiedUTF(t *testing.T) {
	var out bytes.Buffer
	if err := javaUTF(&out, "A\x00é😀"); err != nil {
		t.Fatal(err)
	}
	expected := []byte{0, 11, 65, 0xc0, 0x80, 0xc3, 0xa9, 0xed, 0xa0, 0xbd, 0xed, 0xb8, 0x80}
	if !bytes.Equal(out.Bytes(), expected) {
		t.Fatalf("modified UTF mismatch: %x", out.Bytes())
	}
}
func TestSessionPacket(t *testing.T) {
	cookie := strings.Repeat("a", 80)
	packet, err := sessionPacket(cookie, reply{ID: 11056763246, Username: "test_user", DisplayName: "Tester"})
	if err != nil {
		t.Fatal(err)
	}
	if binary.BigEndian.Uint32(packet[:4]) != 80 || string(packet[4:84]) != cookie || binary.BigEndian.Uint64(packet[84:92]) != 11056763246 {
		t.Fatal("wire format damaged")
	}
	if _, err := sessionPacket(cookie, reply{ID: 1, Username: "bad\nname"}); err == nil {
		t.Fatal("invalid API identity")
	}
}
func TestNoStorageLoginProof(t *testing.T) {
	for _, v := range []string{"", "MATCH", "NATIVE=MATCH WEBVIEW=MATCH CACHE=MATCH OVERRIDE=NONE"} {
		if outcome(v) != "UNVERIFIED" {
			t.Fatal("storage classified as login")
		}
	}
	if outcome("n") != "LOGIN_FAILED" || outcome("v") != "VERIFICATION_REQUIRED" || outcome("y") != "USER_CONFIRMED" {
		t.Fatal("user result damaged")
	}
}
func TestShellPathQuote(t *testing.T) {
	if quote("a'b $()") != "'a'\"'\"'b $()'" {
		t.Fatal("unsafe shell quoting")
	}
}
func TestOutputBound(t *testing.T) {
	var out limitedOutput
	if _, err := out.Write(make([]byte, 16385)); err == nil || out.Len() != 0 {
		t.Fatal("unbounded external output")
	}
}
