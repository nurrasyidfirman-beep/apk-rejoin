module zetsu-termux-test

go 1.24
