package main

import (
	"bufio"
	"bytes"
	"context"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strings"
	"time"
	"unicode/utf16"
)

const pkg = "com.roblox.clienu"

var snapshotPattern = regexp.MustCompile(`^NATIVE=(MATCH|MISSING|DIFFERENT|UNKNOWN) WEBVIEW=(MATCH|MISSING|DIFFERENT|ENCRYPTED|UNKNOWN) CACHE=(MATCH|MISSING|DIFFERENT|UNKNOWN) OVERRIDE=(NONE|MATCH|OTHER|UNKNOWN)$`)
var usernamePattern = regexp.MustCompile(`^[A-Za-z0-9_]{1,50}$`)
var codePattern = regexp.MustCompile(`^[A-Z_0-9]{1,40}$`)

type reply struct {
	OK          bool   `json:"ok"`
	Error       string `json:"error"`
	Package     string `json:"package"`
	SDK         int    `json:"sdk"`
	UID         int    `json:"uid"`
	DataDir     string `json:"dataDir"`
	APKVerified bool   `json:"apkVerified"`
	ID          int64  `json:"id"`
	Username    string `json:"username"`
	DisplayName string `json:"displayName"`
	Snapshot    string `json:"snapshot"`
}
type record struct {
	Time   string `json:"time"`
	Stage  string `json:"stage"`
	Result string `json:"result"`
}
type runner struct {
	jar     string
	records []record
	report  string
}

// Discard stderr and never include external error messages in reports.
type limitedOutput struct{ bytes.Buffer }

func (b *limitedOutput) Write(p []byte) (int, error) {
	if b.Len()+len(p) > 16384 {
		return 0, errors.New("OUTPUT_LIMIT")
	}
	return b.Buffer.Write(p)
}
func quote(s string) string { return "'" + strings.ReplaceAll(s, "'", "'\"'\"'") + "'" }
func (r *runner) call(mode string, input []byte) (reply, error) {
	var result reply
	if mode != "check" && mode != "validate" && mode != "import" && mode != "inspect" && mode != "open" {
		return result, errors.New("COMMAND")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 55*time.Second)
	defer cancel()
	command := "CLASSPATH=" + quote(r.jar) + " exec /system/bin/app_process /system/bin com.zetsu.multilauncher.rejoin.TermuxEntry " + mode
	cmd := exec.CommandContext(ctx, "su", "-c", command)
	cmd.WaitDelay = 3 * time.Second
	cmd.Stdin = bytes.NewReader(input)
	cmd.Stderr = io.Discard
	var output limitedOutput
	cmd.Stdout = &output
	err := cmd.Run()
	if ctx.Err() != nil {
		return result, errors.New("ROOT_TIMEOUT")
	}
	if json.Unmarshal(output.Bytes(), &result) != nil {
		return result, errors.New("ROOT_HELPER_UNAVAILABLE")
	}
	if !result.OK {
		if codePattern.MatchString(result.Error) {
			return result, errors.New(result.Error)
		}
		return result, errors.New("HELPER_FAILED")
	}
	if err != nil {
		return result, errors.New("HELPER_EXIT")
	}
	return result, nil
}
func (r *runner) log(stage, result string) {
	// Only caller-owned status codes or strict storage grammar are accepted.
	if !codePattern.MatchString(result) && !snapshotPattern.MatchString(result) {
		result = "INVALID_STATUS"
	}
	r.records = append(r.records, record{time.Now().Format(time.RFC3339), stage, result})
	fmt.Printf("%s: %s\n", stage, result)
	data, _ := json.MarshalIndent(struct {
		Version string   `json:"version"`
		Package string   `json:"package"`
		Records []record `json:"records"`
	}{"termux-test-0.1.2-launcher-fix", pkg, r.records}, "", "  ")
	// Existing destination must not be followed if replaced with a symlink.
	f, err := os.CreateTemp(filepath.Dir(r.report), ".zetsu-diagnostic-*.tmp")
	if err == nil {
		temp := f.Name()
		_, writeErr := f.Write(data)
		closeErr := f.Close()
		if writeErr == nil && closeErr == nil {
			if os.Rename(temp, r.report) != nil {
				_ = os.Remove(temp)
			}
		} else {
			_ = os.Remove(temp)
		}
	}
}
func normalize(input string) (string, error) {
	if len(input) > 16384 || strings.ContainsAny(input, "\r\n") {
		return "", errors.New("COOKIE_FORMAT")
	}
	value := strings.TrimSpace(input)
	if strings.HasPrefix(value, ".ROBLOSECURITY=") {
		value = strings.TrimPrefix(value, ".ROBLOSECURITY=")
		value = strings.SplitN(value, ";", 2)[0]
	}
	if len(value) < 64 || len(value) > 8192 {
		return "", errors.New("COOKIE_FORMAT")
	}
	for _, b := range []byte(value) {
		if b < 33 || b > 126 || b == ';' || b == '"' || b == ',' {
			return "", errors.New("COOKIE_FORMAT")
		}
	}
	return value, nil
}
func cookiePacket(cookie string) []byte {
	var out bytes.Buffer
	_ = binary.Write(&out, binary.BigEndian, int32(len(cookie)))
	out.WriteString(cookie)
	return out.Bytes()
}

// DataOutputStream.writeUTF uses modified UTF-8, including UTF-16 surrogate pairs.
func javaUTF(out *bytes.Buffer, value string) error {
	var body bytes.Buffer
	for _, c := range utf16.Encode([]rune(value)) {
		if c >= 1 && c <= 0x7f {
			body.WriteByte(byte(c))
		} else if c <= 0x7ff {
			body.WriteByte(0xc0 | byte(c>>6))
			body.WriteByte(0x80 | byte(c&0x3f))
		} else {
			body.WriteByte(0xe0 | byte(c>>12))
			body.WriteByte(0x80 | byte((c>>6)&0x3f))
			body.WriteByte(0x80 | byte(c&0x3f))
		}
	}
	if body.Len() > 65535 {
		return errors.New("API_FORMAT")
	}
	_ = binary.Write(out, binary.BigEndian, uint16(body.Len()))
	out.Write(body.Bytes())
	return nil
}
func sessionPacket(cookie string, account reply) ([]byte, error) {
	if account.ID <= 0 || !usernamePattern.MatchString(account.Username) || len(utf16.Encode([]rune(account.DisplayName))) > 100 {
		return nil, errors.New("API_FORMAT")
	}
	var out bytes.Buffer
	out.Write(cookiePacket(cookie))
	_ = binary.Write(&out, binary.BigEndian, account.ID)
	if err := javaUTF(&out, account.Username); err != nil {
		return nil, err
	}
	if err := javaUTF(&out, account.DisplayName); err != nil {
		return nil, err
	}
	return out.Bytes(), nil
}
func wipe(data []byte) {
	for i := range data {
		data[i] = 0
	}
}
func outcome(answer string) string {
	switch strings.ToLower(strings.TrimSpace(answer)) {
	case "y", "ya":
		return "USER_CONFIRMED"
	case "n", "tidak":
		return "LOGIN_FAILED"
	case "v", "verifikasi":
		return "VERIFICATION_REQUIRED"
	default:
		return "UNVERIFIED"
	}
}
func (r *runner) test() error {
	check, err := r.call("check", nil)
	if err != nil {
		return err
	}
	if check.Package != pkg || check.SDK != 29 || check.UID < 10000 || check.UID >= 100000 || !check.APKVerified {
		return errors.New("PACKAGE_UNSUPPORTED")
	}
	r.log("CHECK", "OK")
	data, err := io.ReadAll(io.LimitReader(os.Stdin, 16386))
	if err != nil {
		return errors.New("COOKIE_INPUT")
	}
	defer wipe(data)
	if len(data) > 16385 {
		return errors.New("COOKIE_FORMAT")
	}
	// The wrapper appends one newline. Reject embedded line breaks, do not silently join them.
	cookie, err := normalize(strings.TrimSuffix(string(data), "\n"))
	if err != nil {
		return err
	}
	validation := cookiePacket(cookie)
	defer wipe(validation)
	account, err := r.call("validate", validation)
	if err != nil {
		return err
	}
	packet, err := sessionPacket(cookie, account)
	if err != nil {
		return err
	}
	defer wipe(packet)
	fmt.Printf("Cookie valid untuk %s (ID %d). Ini belum membuktikan login di aplikasi.\n", account.Username, account.ID)
	r.log("COOKIE_API", "VALID")
	if _, err = r.call("import", packet); err != nil {
		return err
	}
	r.log("IMPORT", "OK")
	if _, err = r.call("open", nil); err != nil {
		return err
	}
	r.log("OPEN", "OK")
	for _, delay := range []time.Duration{3 * time.Second, 7 * time.Second, 20 * time.Second} {
		time.Sleep(delay)
		state, err := r.call("inspect", packet)
		if err != nil {
			return err
		}
		if !snapshotPattern.MatchString(state.Snapshot) {
			return errors.New("HELPER_RESULT")
		}
		r.log("STORAGE", state.Snapshot)
	}
	r.log("LOGIN", "UNVERIFIED")
	tty, err := os.OpenFile("/dev/tty", os.O_RDWR, 0)
	if err != nil {
		return nil
	}
	defer tty.Close()
	fmt.Fprintf(tty, "\nBuka profil Roblox 01. Apakah username %s sudah tampil?\ny = profil sesuai; n = masih Login / Sign Up; v = verifikasi/CAPTCHA\nJawaban: ", account.Username)
	answer, _ := bufio.NewReader(tty).ReadString('\n')
	r.log("USER_REPORT", outcome(answer))
	fmt.Println("Tes selesai. Rotasi otomatis belum dijalankan pada versi tes ini.")
	return nil
}

// Some Android launchers prepend linker arguments. The shell passes the mode
// separately, so never infer it from an arbitrary argument position.
func commandMode(args []string, launcherMode string) (string, error) {
	mode := launcherMode
	if mode == "" && len(args) == 2 {
		mode = args[1]
	}
	if mode != "check" && mode != "test" {
		return "", errors.New("COMMAND")
	}
	return mode, nil
}
func helperPath(bundle, executable string) (string, error) {
	if bundle == "" {
		bundle = filepath.Dir(executable)
	}
	path, err := filepath.Abs(bundle)
	if err != nil {
		return "", errors.New("BUNDLE_PATH")
	}
	path, err = filepath.EvalSymlinks(path)
	if err != nil {
		return "", errors.New("BUNDLE_PATH")
	}
	jar := filepath.Join(path, "cookie-helper.jar")
	info, err := os.Stat(jar)
	if err != nil || !info.Mode().IsRegular() {
		return "", errors.New("HELPER_MISSING")
	}
	return jar, nil
}
func run() int {
	mode, err := commandMode(os.Args, os.Getenv("ZETSU_TERMUX_MODE"))
	if err != nil {
		fmt.Println("Gunakan: bash run.sh check | bash run.sh test")
		return 2
	}
	executable, _ := os.Executable()
	jar, err := helperPath(os.Getenv("ZETSU_TERMUX_BUNDLE"), executable)
	if err != nil {
		fmt.Println(err.Error())
		return 1
	}
	home, err := os.UserHomeDir()
	if err != nil {
		fmt.Println("HOME_MISSING")
		return 1
	}
	lock := filepath.Join(home, ".zetsu-termux-test.lock")
	if err = os.Mkdir(lock, 0700); err != nil {
		fmt.Println("BUSY: proses lain berjalan atau lock tes lama masih ada.")
		return 1
	}
	releaseLock := true
	defer func() {
		if releaseLock {
			_ = os.Remove(lock)
		}
	}()
	r := runner{jar: jar, report: filepath.Join(home, "zetsu-termux-diagnostic.json")}
	if mode == "check" {
		var result reply
		result, err = r.call("check", nil)
		if err == nil {
			r.log("CHECK", "OK")
			fmt.Printf("Android %d, paket %s, root tersedia, APK cocok.\n", result.SDK, result.Package)
		}
	} else {
		err = r.test()
	}
	if err != nil {
		if err.Error() == "ROOT_TIMEOUT" {
			releaseLock = false
		}
		r.log("ERROR", err.Error())
		fmt.Println("Lihat panduan sesuai kode error.")
		return 1
	}
	fmt.Println("Diagnostik tanpa cookie:", r.report)
	return 0
}
func main() { os.Exit(run()) }
