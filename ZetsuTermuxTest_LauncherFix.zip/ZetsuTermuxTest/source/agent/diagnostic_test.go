package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestDiagnosticDoesNotPrintUntrustedValues(t *testing.T) {
	dir, err := os.MkdirTemp(filepath.Join("..", "..", "build", "termux"), "diagnostic-test-")
	if err != nil {
		t.Fatal(err)
	}
	defer os.RemoveAll(dir)
	r := runner{report: filepath.Join(dir, "report.json")}
	secret := "_|WARNING:" + strings.Repeat("secret", 20)
	r.log("ERROR", secret)
	data, err := os.ReadFile(r.report)
	if err != nil {
		t.Fatal(err)
	}
	if strings.Contains(string(data), secret) || !strings.Contains(string(data), "INVALID_STATUS") {
		t.Fatal("secret entered diagnostic")
	}
	r.log("STORAGE", "NATIVE=MATCH WEBVIEW=MATCH CACHE=MATCH OVERRIDE=NONE")
	data, err = os.ReadFile(r.report)
	if err != nil || !strings.Contains(string(data), "NATIVE=MATCH") {
		t.Fatal("diagnostic update failed")
	}
	files, _ := filepath.Glob(filepath.Join(dir, ".zetsu-diagnostic-*"))
	if len(files) != 0 {
		t.Fatal("temporary diagnostic left behind")
	}
}
