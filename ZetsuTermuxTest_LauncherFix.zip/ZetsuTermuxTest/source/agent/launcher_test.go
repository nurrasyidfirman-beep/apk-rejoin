package main

import (
	"os"
	"path/filepath"
	"testing"
)

func TestLauncherModeWithPrependedArguments(t *testing.T) {
	cases := [][]string{
		{"agent-arm64"},
		{"agent-arm64", "check"},
		{"/system/bin/linker64", "agent-arm64", "check"},
		{"/system/bin/linker64", "agent-arm64", "agent-arm64", "check"},
	}
	for _, args := range cases {
		mode, err := commandMode(args, "check")
		if err != nil || mode != "check" {
			t.Fatal("launcher mode lost", args)
		}
		mode, err = commandMode(args, "test")
		if err != nil || mode != "test" {
			t.Fatal("launcher test mode lost", args)
		}
	}
	mode, err := commandMode([]string{"agent", "check"}, "")
	if err != nil || mode != "check" {
		t.Fatal("direct command broken")
	}
	for _, bad := range []string{"invalid", "check; test", "check\n"} {
		if _, err := commandMode([]string{"agent", "check"}, bad); err == nil {
			t.Fatal("invalid mode accepted")
		}
	}
	if _, err := commandMode([]string{"agent", "check", "test"}, ""); err == nil {
		t.Fatal("ambiguous direct argv accepted")
	}
}

func TestHelperPathUsesBundleInsteadOfLinkerExecutable(t *testing.T) {
	dir, err := os.MkdirTemp(filepath.Join("..", "..", "build", "termux"), "launcher-test-")
	if err != nil {
		t.Fatal(err)
	}
	defer os.RemoveAll(dir)
	expected, err := filepath.Abs(filepath.Join(dir, "cookie-helper.jar"))
	if err != nil {
		t.Fatal(err)
	}
	if err = os.WriteFile(expected, []byte("fixture"), 0600); err != nil {
		t.Fatal(err)
	}
	jar, err := helperPath(dir, "/system/bin/linker64")
	if err != nil {
		t.Fatal(err)
	}
	canonical, err := filepath.EvalSymlinks(expected)
	if err != nil || jar != canonical {
		t.Fatal("helper resolved beside linker")
	}
	if err = os.Remove(expected); err != nil {
		t.Fatal(err)
	}
	if _, err = helperPath(dir, "/system/bin/linker64"); err == nil {
		t.Fatal("missing helper accepted")
	}
}
