# Tes login cookie melalui Termux + root

Versi 0.1 menguji satu akun pada Roblox 01 (`com.roblox.clienu`). Tidak perlu memasang atau memperbarui APK Zetsu. Antrean, rotasi 60 detik, logout otomatis, dan auto rejoin belum dijalankan pada tahap tes ini. Pastikan login benar-benar berhasil lebih dulu.

## Mulai di Redfinger

1. Matikan **Auto Rejoin** dan **Rotasi Akun** dalam Zetsu untuk menghindari dua alat mengubah sesi yang sama.
2. Pasang Termux dari sumber resmi: https://github.com/termux/termux-app#installation . Buka Termux dan jalankan:

```bash
pkg update
pkg install unzip
termux-setup-storage
```

3. Izinkan akses penyimpanan. Unduh/salin `ZetsuTermuxTest.zip` ke folder **Download di Android Redfinger**, bukan hanya Download komputer.
4. Di Termux jalankan:

```bash
mkdir -p "$HOME/zetsu-test"
cd "$HOME/zetsu-test"
unzip -o /sdcard/Download/ZetsuTermuxTest.zip
cd ZetsuTermuxTest
sha256sum -c SHA256SUMS
bash run.sh check
```

5. Jika muncul permintaan `su`, izinkan root untuk Termux. Hasil yang diharapkan: `CHECK: OK`. Mode `check` hanya membaca SDK, user, metadata, pemilik folder, dan hash APK; tidak menutup Roblox atau menulis sesi.
6. Untuk tes login:

```bash
bash run.sh test
```

7. Tempel cookie akun milik sendiri pada prompt tersembunyi, lalu Enter. Boleh berupa nilai cookie lengkap termasuk awalan peringatannya, atau `.ROBLOSECURITY=nilai`. Jangan memasukkan cookie sebagai argumen/perintah shell, atau mengirimkannya lewat chat.
8. Alat memvalidasi cookie pada Roblox, menghentikan **paket Roblox 01 saja**, memasang sesi, membuka launcher Roblox 01, lalu membandingkan penyimpanan setelah startup. Tidak menghapus data aplikasi dan tidak menulis cookie global.
9. Sekitar 30 detik ditambah waktu pemeriksaan, buka profil Roblox dan cek username yang ditampilkan oleh Termux. Kembali ke Termux untuk menjawab:

- `y`: username profil sudah sesuai.
- `n`: masih Login / Sign Up.
- `v`: meminta verifikasi atau CAPTCHA; selesaikan manual.

`USER_CONFIRMED` merupakan laporan pengguna, bukan deteksi otomatis. `NATIVE=MATCH WEBVIEW=MATCH CACHE=MATCH` hanya membuktikan nilai penyimpanan sesuai, **bukan bahwa Roblox sudah login**. Jika tetap Login / Sign Up, hentikan di tahap ini dan kirim diagnostik untuk menentukan jalur sesi berikutnya.

## Diagnostik

Laporan hanya memuat tahap dan status, tanpa cookie maupun respons mentah:

```bash
cat "$HOME/zetsu-termux-diagnostic.json"
```

Cookie tidak disimpan sebagai file akun oleh alat ini. Cookie tetap tersimpan dalam penyimpanan Roblox yang dituju setelah impor; ini memang diperlukan untuk tes sesi. Input hanya dipakai dalam memori dan lewat stdin ke helper root, tidak dalam argv. Go tidak dapat menjamin seluruh salinan string rahasia di memori langsung terhapus; array paket biner dibersihkan setelah digunakan.

## Arti error

| Kode | Tindakan |
| --- | --- |
| `ROOT_HELPER_UNAVAILABLE`, `ROOT` | Periksa `su -c id`. Harus `uid=0`. Izinkan root Termux; jangan mengirim cookie ulang sebelum check berhasil. |
| `ROOT_TIMEOUT` | Helper tidak selesai dalam batas waktu. Lock dipertahankan karena proses root mungkin masih berjalan. Jangan langsung mengulang tes; pastikan proses sebelumnya selesai sebelum menghapus lock kosong. |
| `SDK_UNSUPPORTED`, `USER_UNSUPPORTED` | Tes ini khusus Android 10 SDK 29, pengguna Android utama 0. |
| `APK_UNSUPPORTED`, `PACKAGE_UNSUPPORTED`, `PACKAGE_MISSING` | Harus APK Roblox 01 yang persis diperiksa, paket `com.roblox.clienu`, versi 3170. Versi/klon lain belum didukung. |
| `WEBVIEW_MISSING` | Buka Roblox 01 secara manual sampai Login / Sign Up, tutup, ulangi tes. Jika tetap muncul, jangan buat DB kosong secara manual. |
| `WEBVIEW_MULTIPLE` | Ada dua basis data WebView; alat berhenti agar tidak menebak profil. Kirim diagnostik. |
| `GLOBAL_OVERRIDE` | Ada pengaturan cookie global yang bertentangan/tidak terbaca. Alat tidak mengubahnya karena dapat memengaruhi klon lain. Nonaktifkan alat cookie lain sebelum menguji. |
| `ENCRYPTED`, `SCHEMA`, `NATIVE_FORMAT`, `PATH`, `OWNERSHIP` | Format, lokasi, atau kepemilikan sesi tidak sesuai. Kirim diagnostik; jangan menghapus data Roblox sebagai percobaan. |
| `COOKIE_FORMAT` | Tempel satu nilai cookie utuh, tanpa baris baru. |
| `COOKIE_REJECTED` | Roblox menolak cookie tersebut; gunakan sesi aktif akun sendiri. |
| `NETWORK`, `HTTP_429` | Periksa koneksi atau tunggu pembatasan Roblox berakhir. |
| `PARTIAL`, `IMPORT_FAILED` | Jangan mulai rotasi. Impor belum terjamin selesai; kirim diagnostik. Roblox 01 mungkin sudah dihentikan. |
| `LOGIN_FAILED` | Pengguna melaporkan masih Login / Sign Up. Cookie API valid tidak menjamin sesi native diterima. |
| `BUSY` | Tes lain sedang berjalan. Jika sebelumnya Termux crash, pastikan tidak ada agent/helper tersisa; baru hapus folder lock kosong dengan `rmdir "$HOME/.zetsu-termux-test.lock"`. |

## Batas dukungan dan validasi

- APK acuan: `ZETSU ARCEUS 01-2.740.931.apk.apk`.
- SHA-256 APK: `7a1dbe342ef214f1b14269e9240186a76221c61a44f7ac5418c4f269574c20ce`.
- Agen Go dibangun statis untuk Linux arm64 dan amd64, untuk dijalankan pada kernel Android melalui Termux. Helper DEX memakai API Android lewat `app_process` dan `su`.
- HTTPS ke `https://users.roblox.com/v1/users/authenticated` dilakukan helper Android dengan pemeriksaan TLS standar dan tanpa redirect. Tidak memerlukan API key layanan pihak ketiga.
- Jalur profil dipilih dari APK yang diperiksa: `shared_prefs/prefs.xml`, bukan semua file `*_prefs.xml`.
- Tidak memakai `FStringAuthCookie` global untuk login satu klon.
- Kompilasi, tes protokol Go, XML sesi, dan resolver profil diperiksa di komputer. Eksekusi Termux/root dan login nyata di Redfinger **belum diuji** karena tidak ada perangkat terhubung.
- Ini pendekatan impor sesi yang perlu dibuktikan pada perangkat. Beralih dari APK ke Go tidak otomatis menyelesaikan Login / Sign Up.

Sumber kode disertakan dalam folder `source`. Script loader vendor tidak dijalankan dan tidak dipaketkan.
